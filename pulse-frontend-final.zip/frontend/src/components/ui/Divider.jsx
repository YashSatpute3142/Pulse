export function Divider({ className = '' }) {
  return <hr className={`border-0 border-t border-line ${className}`} />;
}
